
## Description
I have left a key to the chest at the end of the maze.

connect to the instance at : `nc filtermaze.2025.ctfcompetition.com 1337`

## Attachment : 
find the attached zip file with the name \
`5c70435762090e1cecc6cf8b8704b1812bfcae0fd0fabf4ab579a46892130d159a2fcd8543c06e7dca886f4999d22beb8ef7e812291bae763f37348558878bb8 (1).zip`