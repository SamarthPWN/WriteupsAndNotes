To build the app:
docker built -t chal .

To run:
docker run -p 50001:1337 chal

To visit a reported link as admin:
Login with these credentials on separate browser:
admin:admin
Visit the share link. 

Target:
Make a solution script which auto exfiltrates the flag when admin visits a reported book. 
Provide walkthroughs on how you approached the challenge and found the parts to get the flag. 